Check Morfy documentation for more details: http://morfy.org/documentation
